const fs = require("fs/promises");
const path = require("path");
const prisma = require("../config/db");
const env = require("../config/env");
const ApiError = require("../utils/ApiError");
const { NODE_TYPES } = require("../constants");
const storageService = require("./storage.service");
const uploadRoot = path.join(process.cwd(), env.uploadDir);

// ---------------------------------------------------------------------------
// Internal helpers
// ---------------------------------------------------------------------------

async function getNodeOrThrow(id, ownerId) {
  const node = await prisma.node.findFirst({ where: { id, ownerId } });
  if (!node) throw ApiError.notFound("Item not found");
  return node;
}

/**
 * Returns every id in the subtree rooted at `rootId` (including the root
 * itself), using a recursive CTE — one indexed query instead of N+1 walks.
 * Relies on the (ownerId, parentId) and (parentId) indexes on `nodes`.
 */
async function getSubtreeIds(rootId, ownerId) {
  const rows = await prisma.$queryRaw`
    WITH RECURSIVE subtree AS (
      SELECT id, "parentId", 0 AS depth
      FROM nodes
      WHERE id = ${rootId}::uuid AND "ownerId" = ${ownerId}::uuid
      UNION ALL
      SELECT n.id, n."parentId", s.depth + 1
      FROM nodes n
      INNER JOIN subtree s ON n."parentId" = s.id
    )
    SELECT id, "parentId", depth FROM subtree ORDER BY depth ASC;
  `;
  return rows;
}

async function assertFolderAndUsable(parentId, ownerId) {
  if (parentId === null || parentId === undefined) return; // root is always valid
  const parent = await getNodeOrThrow(parentId, ownerId);
  if (parent.type !== NODE_TYPES.FOLDER) {
    throw ApiError.badRequest("Target parent is not a folder");
  }
  if (parent.trashed) {
    throw ApiError.badRequest("Cannot use a trashed folder as a destination");
  }
  return parent;
}

async function deleteFilesFromDisk(storagePaths) {
  await Promise.all(
    storagePaths
      .filter(Boolean)
      .map((p) => fs.unlink(path.join(uploadRoot, p)).catch(() => { }))
  );
}

// ---------------------------------------------------------------------------
// Listing / reading
// ---------------------------------------------------------------------------

async function listChildren(ownerId, parentId) {
  const where = {
    ownerId,
    trashed: false,
    parentId: parentId === "null" || parentId === undefined ? null : parentId,
  };
  if (where.parentId) {
    await assertFolderAndUsable(where.parentId, ownerId);
  }
  return prisma.node.findMany({
    where,
    orderBy: [{ type: "asc" }, { name: "asc" }],
  });
}

/** Only returns the *roots* of trashed subtrees — i.e. items the user
 * actually trashed directly, not every descendant swept up with them.
 * Mirrors how a real OS trash bin displays entries. */
async function listTrash(ownerId) {
  const trashedNodes = await prisma.node.findMany({
    where: { ownerId, trashed: true },
    orderBy: { trashedAt: "desc" },
  });
  const trashedIds = new Set(trashedNodes.map((n) => n.id));
  return trashedNodes.filter((n) => !n.parentId || !trashedIds.has(n.parentId));
}

async function searchNodes(ownerId, query) {
  return prisma.node.findMany({
    where: {
      ownerId,
      trashed: false,
      name: { contains: query, mode: "insensitive" },
    },
    orderBy: { updatedAt: "desc" },
    take: 50,
  });
}

async function getPath(ownerId, id) {
  const rows = await prisma.$queryRaw`
    WITH RECURSIVE ancestors AS (
      SELECT id, "parentId", name, type, 0 AS depth
      FROM nodes
      WHERE id = ${id}::uuid AND "ownerId" = ${ownerId}::uuid
      UNION ALL
      SELECT n.id, n."parentId", n.name, n.type, a.depth + 1
      FROM nodes n
      INNER JOIN ancestors a ON n.id = a."parentId"
    )
    SELECT id, name, type FROM ancestors ORDER BY depth DESC;
  `;
  if (rows.length === 0) throw ApiError.notFound("Item not found");
  return rows;
}

/**
 * Returns EVERY node belonging to the owner — files, folders, trashed or
 * not — in one query. This is intentionally the only "give me everything"
 * endpoint in the API; it exists specifically so a client can hydrate a
 * full local tree cache in a single round trip on login rather than
 * walking folder-by-folder. Fine at personal-workspace scale; if this
 * were ever handling thousands of nodes per user, replace this with the
 * existing paginated `listChildren` and lazy-load per folder instead.
 */
async function getFullTree(ownerId) {
  return prisma.node.findMany({
    where: { ownerId },
    orderBy: [{ type: "asc" }, { name: "asc" }],
  });
}

async function getWorkspaceStats(ownerId) {
  const [totalFiles, totalFolders, trashedCount, sizeAgg] = await Promise.all([
    prisma.node.count({ where: { ownerId, trashed: false, type: NODE_TYPES.FILE } }),
    prisma.node.count({ where: { ownerId, trashed: false, type: NODE_TYPES.FOLDER } }),
    prisma.node.count({ where: { ownerId, trashed: true } }),
    prisma.node.aggregate({
      where: { ownerId, trashed: false, type: NODE_TYPES.FILE },
      _sum: { size: true },
    }),
  ]);
  return {
    totalFiles,
    totalFolders,
    trashedCount,
    totalSizeBytes: sizeAgg._sum.size || 0,
  };
}

// ---------------------------------------------------------------------------
// Mutations
// ---------------------------------------------------------------------------

async function createFolder(ownerId, { parentId, name }) {
  await assertFolderAndUsable(parentId, ownerId);
  return prisma.node.create({
    data: { ownerId, parentId: parentId ?? null, type: NODE_TYPES.FOLDER, name },
  });
}

async function createFile(ownerId, { parentId, name, content }) {
  await assertFolderAndUsable(parentId, ownerId);
  return prisma.node.create({
    data: {
      ownerId,
      parentId: parentId ?? null,
      type: NODE_TYPES.FILE,
      name,
      content: content ?? "",
      size: Buffer.byteLength(content ?? "", "utf8"),
      mimeType: "text/plain",
    },
  });
}

async function importFile(ownerId, { parentId, file }) {
  await assertFolderAndUsable(parentId, ownerId);

  const uploaded = await storageService.uploadFile(file, ownerId);

  return prisma.node.create({
    data: {
      ownerId,
      parentId: parentId ?? null,
      type: NODE_TYPES.FILE,
      name: file.originalname,
      mimeType: file.mimetype,
      size: file.size,

      storagePath: uploaded.url,
      imagekitFileId: uploaded.fileId,
      thumbnailUrl: uploaded.thumbnailUrl,
    },
  });
}
async function updateContent(id, ownerId, content) {
  const node = await getNodeOrThrow(id, ownerId);
  if (node.trashed) throw ApiError.badRequest("Cannot edit an item in the trash");
  if (node.type !== NODE_TYPES.FILE) throw ApiError.badRequest("Only files have content");
  return prisma.node.update({
    where: { id },
    data: { content, size: Buffer.byteLength(content, "utf8") },
  });
}

async function renameNode(id, ownerId, name) {
  const node = await getNodeOrThrow(id, ownerId);
  if (node.trashed) throw ApiError.badRequest("Restore this item before renaming it");
  return prisma.node.update({ where: { id }, data: { name } });
}

async function moveNode(id, ownerId, newParentId) {
  const node = await getNodeOrThrow(id, ownerId);
  if (node.trashed) throw ApiError.badRequest("Restore this item before moving it");

  if (newParentId === id) {
    throw ApiError.badRequest("Cannot move an item into itself");
  }

  await assertFolderAndUsable(newParentId, ownerId);

  if (newParentId) {
    const subtree = await getSubtreeIds(id, ownerId);
    if (subtree.some((n) => n.id === newParentId)) {
      throw ApiError.badRequest("Cannot move a folder into its own subtree");
    }
  }

  return prisma.node.update({ where: { id }, data: { parentId: newParentId } });
}

async function duplicateNode(id, ownerId) {
  const node = await getNodeOrThrow(id, ownerId);
  if (node.trashed) throw ApiError.badRequest("Restore this item before duplicating it");

  let newStoragePath = null;
  if (node.storagePath) {
    const ext = path.extname(node.storagePath);
    newStoragePath = `${require("crypto").randomUUID()}${ext}`;
    await fs.copyFile(
      path.join(uploadRoot, node.storagePath),
      path.join(uploadRoot, newStoragePath)
    );
  }

  return prisma.node.create({
    data: {
      ownerId,
      parentId: node.parentId,
      type: node.type,
      name: `${node.name} copy`,
      content: node.content,
      mimeType: node.mimeType,
      size: node.size,
      storagePath: newStoragePath,
    },
  });
}

/**
 * Trashes a node and its entire subtree in one transaction. Descendants
 * keep their real parentId untouched (so tree shape is preserved for a
 * later cascade restore) — only the root of the trashed subtree records
 * `originalParentId`, used to know where to reattach it on restore.
 */
async function trashNode(id, ownerId) {
  const node = await getNodeOrThrow(id, ownerId);
  if (node.trashed) throw ApiError.badRequest("Item is already in the trash");

  const subtree = await getSubtreeIds(id, ownerId);
  const now = new Date();

  await prisma.$transaction([
    prisma.node.update({
      where: { id },
      data: { trashed: true, trashedAt: now, originalParentId: node.parentId },
    }),
    prisma.node.updateMany({
      where: { id: { in: subtree.map((n) => n.id).filter((sid) => sid !== id) } },
      data: { trashed: true, trashedAt: now },
    }),
  ]);

  return { trashedCount: subtree.length };
}

/**
 * Restores a node. The target itself is always restored, reattached to its
 * originalParentId if that folder still exists and isn't itself trashed
 * (otherwise it lands at root). Descendants cascade back only if their
 * current parent is being restored too — processed in depth order so each
 * child sees its parent's freshly-restored state.
 */
async function restoreNode(id, ownerId) {
  const node = await getNodeOrThrow(id, ownerId);
  if (!node.trashed) throw ApiError.badRequest("Item is not in the trash");

  const subtree = await getSubtreeIds(id, ownerId); // ordered by depth asc
  const subtreeNodes = await prisma.node.findMany({
    where: { id: { in: subtree.map((n) => n.id) } },
  });
  const byId = new Map(subtreeNodes.map((n) => [n.id, n]));

  const willRestore = new Set();
  for (const row of subtree) {
    if (row.id === id) {
      willRestore.add(row.id);
      continue;
    }
    const current = byId.get(row.id);
    const parent = byId.get(current.parentId);
    if (parent && (willRestore.has(parent.id) || parent.trashed === false)) {
      willRestore.add(row.id);
    }
  }

  // Resolve where the root should reattach.
  let resolvedParentId = null;
  if (node.originalParentId) {
    const originalParent = await prisma.node.findFirst({
      where: { id: node.originalParentId, ownerId, trashed: false },
    });
    if (originalParent) resolvedParentId = originalParent.id;
  }

  const updates = [...willRestore].map((nid) =>
    prisma.node.update({
      where: { id: nid },
      data:
        nid === id
          ? { trashed: false, trashedAt: null, originalParentId: null, parentId: resolvedParentId }
          : { trashed: false, trashedAt: null },
    })
  );

  await prisma.$transaction(updates);
  return { restoredCount: updates.length };
}

/** Permanently deletes a node + its subtree. Only allowed once the item is
 * already trashed — this IS the "hard delete" path, and it is the ONLY one. */
async function deleteForever(id, ownerId) {
  const node = await getNodeOrThrow(id, ownerId);
  if (!node.trashed) {
    throw ApiError.badRequest("Move this item to the trash before deleting it permanently");
  }

  const subtree = await getSubtreeIds(id, ownerId);
  const ids = subtree.map((n) => n.id);

  const filesToRemove = await prisma.node.findMany({
    where: { id: { in: ids }, storagePath: { not: null } },
    select: { storagePath: true },
  });

  await prisma.node.deleteMany({ where: { id: { in: ids } } });
  await deleteFilesFromDisk(filesToRemove.map((f) => f.storagePath));

  return { deletedCount: ids.length };
}

async function emptyTrash(ownerId) {
  const trashedNodes = await prisma.node.findMany({
    where: { ownerId, trashed: true },
    select: { id: true, storagePath: true },
  });

  await prisma.node.deleteMany({ where: { ownerId, trashed: true } });
  await deleteFilesFromDisk(trashedNodes.map((n) => n.storagePath));

  return { deletedCount: trashedNodes.length };
}

async function getDownloadInfo(id, ownerId) {

    const node = await getNodeOrThrow(id, ownerId);

    if (!node.storagePath) {
        throw ApiError.notFound("File not found");
    }

    return {
        storagePath: node.storagePath,
        name: node.name,
        mimeType: node.mimeType,
    };
}

module.exports = {
  getFullTree,
  listChildren,
  listTrash,
  searchNodes,
  getPath,
  getWorkspaceStats,
  createFolder,
  createFile,
  importFile,
  updateContent,
  renameNode,
  moveNode,
  duplicateNode,
  trashNode,
  restoreNode,
  deleteForever,
  emptyTrash,
  getDownloadInfo,
  getNodeOrThrow,
};
